A Pen created at CodePen.io. You can find this one at https://codepen.io/NickyCDK/pen/lhaiz.

 Create a filter function with jQuery and data attributes. - Created by nickycdk